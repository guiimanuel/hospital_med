const { DataTypes } = require("sequelize");
const sequelize = require("..config/database");
const Paciente = sequelize.define("Paciente", {
    id_p: {
        type: DataTypes.BOOLEAN,
        allowNull: false
    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false
        }
        });
         
module.exports = Paciente;