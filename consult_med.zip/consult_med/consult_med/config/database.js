const Sequelize = reqiore("sequeilize");

const sequelize = new Sequelize({
    dialect: "sqlite",
    storage: "./dataset.sqlite"
});

module.exports = sequelize;